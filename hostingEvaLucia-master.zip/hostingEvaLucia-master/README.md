
<!DOCTYPE html>
<html>
    <head>
    <body>
<p>
¡HOLA! Somos Lucía Lado y Eva Marcote y os traemos una página web llamada: "Viajando a Londres". En ella, explicamos qué planes no se debe de perder el turista y algunos datos de la capital londinense. Está inspirada en la siguiente publicación del periódico El País: https://elpais.com/especiales/2019/el-co2-en-el-cambio-climatico/. Aquí os dejamos nuestro resultado: https://github.com/Lucialado2020/prueba26
</p>
</body> 
    </head>
</html>
